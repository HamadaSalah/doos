<?php

return [
    'treatment_status' => [
        'home' => 'توصيل الى المنزل', 
        'company' => 'من موقع الشركة'
    ]
];
